# ift

InterFace Toolkit 接口工具集

by 鬼道（[luics](http://luics.github.io)）

## 安装

```
tnpm install -g ift
```

MAC 用户请使用`sudo tnpm install -g ift`

## 1. 初始化

> 请使用 `ift -h` 查看所有命令

请在项目根目录下运行

```
ift -i
```

or

```
ift --init
```

会影响的文件结构为

```
demo/
--data/
----demo.js
----if-config.json
doc/
```

### 数据文件

`ift -i` 生成的 [demo.js](http://gitlab.alibaba-inc.com/luics/if/blob/master/demo/data/demo.js) 是一个 IF 数据文件，即可以作为调试数据使用（`ift -e`），又能生成接口文档（`ift -s`）。
下面显示了重要的配置信息：

```javascript
exports.config = {
    "name": "这是接口名",
    "desc": "这是接口的详细描述",
    // 线上地址
    "url": "http://example.com/demo",
    // 日常地址
    "urlDaily": "http://daily.example.net/demo",
    // 预发地址
    "urlPrepub": "http://example.com/demo",
    // 支持的 Method 集合
    "method": ['GET', 'POST'],
    // 响应与模板的映射关系
    "template":{
        "response": "tpl1.php",
        "responseError": "tpl2.php"
    }
};
```


## 2. 文档同步

用于将数据文件 [demo.js](http://gitlab.alibaba-inc.com/luics/if/blob/master/demo/data/demo.js) 生成接口文档

请在项目根目录下运行（首次运行该命令前请先运行`ift --init`）

```
ift -s
```

or

```
ift --sync
```

该命令默认读取的配置文件位于 `demo/data/if-config.json`，所有数据文件均位于 `demo/data/`

默认生成的接口文档为 `doc/api.md`（查看 [api.md 文档](http://gitlab.alibaba-inc.com/luics/if/blob/master/doc/api.md)）

```
doc/
--api.md
```

### if-config.json
 [if-config.json](http://gitlab.alibaba-inc.com/luics/if/blob/master/demo/data/if-config.json) 是接口文档配置文件

```javascript
{
    "title": "接口文档",
    "extraHtml": "<h3>额外的html片段</h3>",
    "savePath": "../../doc/api.md",
    "files": [
        "demo"
    ]
}
```

0. `savePath` 设置保存接口文档的相对路径
0. `files` 指定接口文件，无需文件扩展名

## 3. 接口服务器

请在项目根目录下运行

```
ift -e -p 9999
```

or

```
ift --server --port 9999
```

浏览器中访问 `http://localhost:9999/demo.js`，`demo.js` 可替换为合适的值

## 4. 接口校验

0. 运行于 node 环境
    * 调用
    
        ```javascript
        require('ift').ifCheck({data-format:1}, {data:1});
        ```
    * 返回
    
        ```javascript
        {
          "pass": 1, // 1-校验通过 0-未通过
          "defined": 4, // 校验的字段数
          "undefined": 0, // 需要定义却未定义的字段数
          "mismatch": 0, // 格式不匹配的字段数
          "stack": [ // 校验堆栈，一般用不着
              "{root}"
          ],
          "log": [] // 出错日志
        }
        ```
0. 运行于 browser 环境
    * 调用
    
        ```javascript
        window.ifCheck({data-format:1}, {data:1});
        ```
    * 返回 同 node 版本
0. HTTP API，方便集成 
    * http://if.alibaba-inc.com/check 支持 POST/GET
    * 文档见 http://gitlab.alibaba-inc.com/x/ifcheck/blob/master/demo/api.md
    * [Demo（HTTP GET）](http://if.alibaba-inc.com/check?data=http%3A%2F%2Fbar.tmall.com%2FgetMallBar.htm%3Fcallback%3D__mallbarGetMallBar%26shopId%3D%26_input_charset%3DUTF-8%26v%3D1.2.3&format=http%3A%2F%2Fg.assets.daily.taobao.net%2Fmui%2Fmallbar%2F1.2.3%2Fifdata%2FgetMallBar.js&headers=%7B%22referer%22%3A%22http%3A%2F%2Fwww.tmall.com%22%7D%20)
0. [UI 工具](http://demo.tmall.net/toolkit/public/#json.html)