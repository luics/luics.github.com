var syncIf = require('if-sync').syncIf;
var path = require('path');

syncIf({
    title: 'IF Demo 接口文档',
    //extraHtml: '<img src="http://work.tmall.net/attachments/download/727/tsp.png" alt="总览" width="750" />',
    encoding: 'utf-8',
    basePath: __dirname,
    savePath: path.join(__dirname, '../../doc/api.md'),
    files: [
        'demo'
    ]
});