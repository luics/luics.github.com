/**
 * Util library
 * 工具库
 *
 * @author luics (guidao)
 * @version 1.0.0
 * @date 5/20/13 5:49 PM
 */

var __REQUIRES = [
    'xtemplate',    
    'tml/overlay',
    'tml/minilogin'
];

KISSY.add('tm/if/util', function(S, XTemplate, O, MLogin) {

    var Seed = {
        /**
         * 封装 window.console.log，使用 S.Config.debug 开关控制 log 是否打印
         */
        log: function() {
            if (!S.Config.debug) {
                return;
            }

            // TODO var con = window.console; 赋值有风险？
            // 遇到过 var $ = document.querySelectorAll, 之后$为undefined $()
            if (window.console && window.console.log) {
                window.console.log.apply(window.console, arguments);
            }
        },
        /**
         * 字符串格式化
         *
         * Usage：
         *   fm('{0}-{1}', 1, '2') // 结果：1-2
         *   fm('{0}-{1}-{0}', 1, '2') // 结果：1-2-1
         *
         * @returns {string}
         */
        fm: function() {
            if (arguments.length == 0) {
                return '';
            }
            else if (arguments.length == 1) {
                return arguments[0];
            }

            var res = arguments[0], i;
            for (i = 1; i < arguments.length; ++i) {
                var re = new RegExp('\\{' + (i - 1) + '\\}', 'g');
                res = res.replace(re, arguments[i]);
            }
            // TODO 性能优化版本
            return res;
        }
    };

    var U = Seed;

    /**
     * loading 控制
     * @param {Object} [opt]
     * @param {boolean} opt.hide
     */
    U.loading = function(opt) {
        opt = opt || {};
        var $loading = S.one('.ui-if-loading');
        if (!$loading) {
            S.one(document.body).append('<div class="ui-loading ui-mk-loading"></div>');
            $loading = S.one('.ui-mk-loading');
        }
        opt.hide ? $loading.hide() : $loading.show();
    };

    /**
     * @param {Object} cfg 参考tml/alert
     */
    U.alert = function(cfg) {
        if (S.isString(arguments[0])) {
            var _cfg = {};
            _cfg.tip = arguments[0];
            cfg = _cfg;
            if (S.isFunction(arguments[1])) cfg.callback = arguments[1];
            if (S.isObject(arguments[2])) cfg = S.merge(cfg, arguments[2]);
        }
        cfg = cfg || {};
        cfg.closeAction = 'destroy';
        cfg.zIndex = cfg.zIndex || 999999;

        var d = new O.Alert(cfg);
        d.render();
        d.show();
    };

    /**
     * 封装 KISSY.ajax，增加 mock data 支持
     *
     * Usage 参见 Unit Test ../tests/test.util.js
     *
     * @param {Object} opt
     * @param {string} [opt._mockUrl] mock data url
     * @param {string} [opt._loading] loading 容器的选择器
     *
     * @param {string} opt.url
     * @param {function} [opt.success]
     * @param {Object} [opt.data]
     * @param {string} [opt.type]
     * @param {string} [opt.dataType]
     * @param {number} [opt.timeout]
     * @param {function} [opt.error]
     * @param {function} [opt.complete]
     * @param {string} [opt.scriptCharset]
     *
     * @see 参数详细定义请参见 KISSY.ajax 源码
     */
    U.ajax = function(opt) {
        var success = opt.success;
        var complete = opt.complete;

        /**
         * 处理服务器返回的数据
         *
         * @param {Object} result 服务器返回json解析后的对象
         * @param {Object} result.success 服务器状态，是否成功
         * @param {Object} result.model 返回的数据
         * @param {string} result.model.redirect 重定向url
         * @param {string} result.model.needLogin 会话超时
         */
        function ondata(result) {
            U.log('U.ajax ondata', result);
            var model = result.model;
            if (!result.success) {// && !
                if (model.global) {
                    //U.alert(model.global);
                    location.href = 'http://err.tmall.com/error2.html';
                    return false;
                }
                else if (model.error) {
                    U.log('ondata error: ', model.error);
                }
                else if (!S.isEmptyObject(model.formError)) { // [] | {} 非空时，[]是为了兼容tmc的一个格式错误
                    U.log('ondata formError: ', model.formError);
                }
                else if (model.needLogin) {
                    U.log('needLogin');
                    // 登录成功后刷新页面
                    MLogin.show(function() {
                        U.log('login success, document.domain:', document.domain);
                    }, {
                        needRedirect: false
                    });
                    // 中断处理
                    // CASE 会话超时处理，考虑iframe的情况
                    return;
                }
                else if (model.redirect) {
                    location.href = model.redirect;
                    return false;
                }
                else {
                    U.alert('未知错误，请联系我们');
                }
            }

            success && success(result);
        }

        // 重写 opt
        if (S.Config.debug) {
            opt.type = 'get';
            opt.dataType = 'script';

            var query = '';
            var path = opt.url;
            if (opt.url.indexOf('?') >= 0) {
                var seg = opt.url.split('?');
                path = seg[0];
                query = seg[1];
            }
            var filename = path.substring(path.lastIndexOf('/') + 1, // 必须包含路径
                (path.lastIndexOf('.') >= 0 ? path.lastIndexOf('.') : path.length));
            path = U.fm('data/{0}.js{1}', filename, (query ? '?' + query : ''));
            opt.url = opt._mockUrl ? opt._mockUrl : path;

            opt.success = function() {
                ondata(exports.response);
            };
        }
        else {
            opt.type = opt.type || 'post';
            opt.dataType = opt.dataType || 'json';
            opt.success = function(data) {// 后端字符编码是 gbk
                ondata(data);
            };
        }

        var hasQuery = opt.url.lastIndexOf('?') > -1;
        opt.url = U.fm('{0}{1}_input_charset=UTF-8', opt.url, hasQuery ? '&' : '?');

        opt.timeout = opt.timeout || 5;
        opt.error = opt.error || function(textStatus) {
            U.log('U.ajax error: ', textStatus);
        };

        U.loading();
        opt.complete = function(textStatus) {
            U.loading({hide: true});

            complete && complete(textStatus);
        };

        // CSRF防攻击字段
        // 详见：http://www.cnblogs.com/hyddd/archive/2009/04/09/1432744.html
        opt.data = opt.data || {};
        opt.data._tb_token_ = S.one('#_tb_token_') ? S.one('#_tb_token_').val() : '';

        S.ajax(opt);
    };

    // end  
    return U;
}, {requires: __REQUIRES});