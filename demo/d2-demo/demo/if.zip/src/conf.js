/**
 * TSP Config
 *
 * @author luics (guidao)
 * @version 1.0.0
 * @date 5/20/13 5:49 PM
 */
//CASE js编码应该utf8
KISSY.add('tm/if/conf', function(S) {
    var TIMESTAMP = '2013-06-27 22:00'; // 方便查看线上更新情况

    /**
     * 本地联调的方式
     */
    var DEBUG = location.href.indexOf('___debug=1') > -1;

    S.Config.debug = DEBUG;

    var HOST = '/';
    var SERVER = HOST + 'if/';

    /**
     * 拼装服务器URL
     *
     * @param name
     * @return {string}
     */
    function getUrl(name) {
        return SERVER + name + '.do';
    }

    var Conf = {
        PAGE_SIZE: 10,
        FM_DATETIME: 'yyyy-mm-dd HH:MM:ss',
        FM_DATE: 'yyyy-mm-dd',
        CK_USED: '__tsp_used',
        VALID: '.ui-form-valid',
        URL: {
            DEMO: getUrl('demo')
        }
    };

    return Conf;
});