/**
 * 天猫店铺优惠 - 查看活动
 *
 * @author luics (guidao)
 * @version 1.0.0
 * @date 5/20/13 5:22 PM
 */
var __IMPORT = [
    'xtemplate',
    'tm/if/conf',
    'tm/if/util'
].join(',');

KISSY.use(__IMPORT, function(S, XTemplate, Conf, U) {
    var model = {};

    function init() {
        model = {
            // 展示结果
            result: S.one('#J_Result'),
            // 列表数据
            listData: {}
        };

        U.ajax({
            url: Conf.URL.DEMO,
            data: {
                id: 1000,
                name: 'name'
            },
            success: function(result) {
                var m = result.model;
                if (!result.success) {
                    U.alert(m.error);
                    return;
                }
                // 保存数据
                model.listData = m;
                // 展示结果
                model.result.html(TPL.render(m.list));
            }
        });
    }

    var TPL = new XTemplate([
        '<table class="ui-list" cellpadding="0" cellspacing="0">',
        '  <thead>',
        '    <tr><td>id</td><td>name</td></tr>',
        '  </thead>',
        '  <tbody>',
        '  {{#each this}}',
        '  <tr>',
        '  <td>{{id}}</td>',
        '  <td>{{name}}</td>',
        '  </tr>',
        '  {{/each}}',
        '  </tbody></table>'
    ].join(''));
    init();
});