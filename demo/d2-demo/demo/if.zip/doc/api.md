# IF Demo 接口文档

> 该文档由[if-sync](http://work.tmall.net/projects/if/wiki/sync)生成，请勿手工改动

* [if](http://work.tmall.net/projects/if/wiki)，天猫前后端接口项目
* [if-spec](http://work.tmall.net/projects/if/wiki/Spec)，接口规范文档
* [if-check](http://demo.tmall.net/toolkit/public/#json.html)，接口校验工具
* 任何建议都欢迎提给 @鬼道



## /demo (这是接口名)

这是接口的详细描述

### Request 

`POST /demo`

```javascript
{
    "id": "1000"   // 查询字段 
}
```

### Response

#### Success

```javascript
{
    "success": true,
    "model": {
        "title": "通过Ajax获取的数据", 
        "list": [// 列表数据
            {// 单条记录
                "id": "1000",
                "name": "name abc"
            },
            {
                "id": "1000",
                "name": "name abc"
            }
        ]
    }
}
```

#### Error

```javascript
{
    "success": false,
    "model": {
        "error": "Error message"
    }
}
```
